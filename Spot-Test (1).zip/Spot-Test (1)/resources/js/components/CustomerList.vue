<template>
    <div class="app">
        <h1>Customer List</h1>
    </div>
</template>

<script>
export default {

}
</script>

<style  scoped>

</style>
